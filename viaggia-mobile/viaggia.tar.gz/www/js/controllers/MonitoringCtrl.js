angular.module('viaggia.controllers.monitoring', [])

.controller('MonitoringCtrl', function ($scope) {



})
